import moment from "moment";
import { momentLocalizer } from "react-big-calendar";

export const localizer = momentLocalizer(moment);
